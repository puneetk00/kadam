<?php
 
namespace Kadam\Erply\Plugin\Catalog\Block\Product;

use Magento\Catalog\Model\Product;
use Magento\Customer\Api\GroupManagementInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Store\Model\Store;
use Magento\Catalog\Api\Data\ProductTierPriceExtensionFactory;
use Magento\Framework\App\ObjectManager;
use Magento\Store\Api\Data\WebsiteInterface;

class ListProduct
{  

	protected $itemArray;
	/**
     * Constructor
     *
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\Customer\Model\Session $customerSession,
        PriceCurrencyInterface $priceCurrency,
        GroupManagementInterface $groupManagement,
        \Magento\Catalog\Api\Data\ProductTierPriceInterfaceFactory $tierPriceFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $config,
        ProductTierPriceExtensionFactory $tierPriceExtensionFactory = null,
		\Magento\Framework\View\Element\Template\Context $context
    ){
        $this->_storeManager = $storeManager;
        $this->_localeDate = $localeDate;
        $this->_customerSession = $customerSession;
       
    }

	
    public function afterGetLoadedProductCollection(\Magento\Catalog\Block\Product\ListProduct $subject, $_getProductCollection){ 
		$customerSession = $this->ObjectManager()->create('Magento\Customer\Model\Session');
		$listpr = json_decode($customerSession->getCustomer()->getData("erply_prilist"),true);	
		$itemArray = array();
		if ($customerSession->isLoggedIn()) {
			foreach($_getProductCollection as $product)
			{
				$pr = $this->ObjectManager()->create('Magento\Catalog\Model\Product');
				$erp_pr_group = json_decode($pr->load($product->getId())->getData('erply_product_group'));
				if(isset($erp_pr_group))
				{	
					if(isset($listpr[$erp_pr_group])){			
						$itemArray[$product->getId()] = ($product->getPrice()-($product->getPrice()*$listpr[$erp_pr_group]) /100);  
					}			
				}			
			}
			
			
		}
		$customerSession->setPriceCached($itemArray);
		return $_getProductCollection;
	}
	
	/** 
	* Create log
	**/
	public function logger(){
		$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/p21pricelist.log');
		$logger = new \Zend\Log\Logger();
		$logger->addWriter($writer);
		return $logger;
	}
	
	


	/**
	* P21 price getting function
	**/
	public function getPriceFromP21($productArray = null) 
	{
		$isLoggedIn = $this->getLoggedInPrice();
		$companyId = $this->getCurrentCompany();
		$locationId = $this->getCurrentLocation();
		
		$authToken = $this->getAuthorizationToken();
		//Get Customer Pricings

		// DEV Api
		$custPricingsUrl = 'http://testapi.jaybro.com.au:4443/api/v1/CustomerPricings/search/CustomerIdAndItemUOMs';
		// LIVE Api
		//$custPricingsUrl = 'http://api.jaybro.com.au:88/api/v1/CustomerPricings/search/CustomerIdAndItemUOMs';

		$custPricingsConfig = array(
			'CompanyId' => $companyId,
			'CustomerId' => $isLoggedIn,
			'LocationId' => $locationId,
			'Items' => $productArray,
			'JobContractUid' => 'NULL'
		);
		
		$custPricingsContext = array(
			'http' => array(
				'method'  => 'POST',
				'header' => "Authorization: {$authToken}\r\n". 
					"Content-type: application/json\r\n".
					"Connection: close",
				'content' => json_encode($custPricingsConfig)
				//'timeout' => 2
			)
		);

		$this->logger()->info("Pricing Call: " . $custPricingsUrl);
		$this->logger()->info("Pricing Call: " . var_export($custPricingsContext, true));
		
		$custPricingsCreate = stream_context_create($custPricingsContext);
		try {
			$custPricingsPost = file_get_contents($custPricingsUrl, false, $custPricingsCreate);
		} catch (Exception $e) {
			$this->logger()->info( "Exception getting Pricing - WorldSynergy_P21Integration_Model_Catalog_Price: " . $e->getMessage() );
			$this->logger()->info( $custPricingsContext );
		}
		
		$custPricings = json_decode($custPricingsPost, true);

		return $custPricings;
	}
	
	public function getCurrentStoreDefaultCustomer() {
		$websiteId = $this->_storeManager->getWebsite()->getId();
		
		if ($websiteId == "2") {
			return "285265";
		}

		return "143579";
	}
	
	public function getCurrentCompany() 
	{
		$websiteId = $this->_storeManager->getWebsite()->getId();
		
		if ($websiteId == "2") {
			return "50";
		}

		return "10";
	}
	
	public function getCurrentLocation() 
	{
		$websiteId = $this->_storeManager->getWebsite()->getId();
		
		if ($websiteId == "2") {
			return "5902";
		}

		return "1201";
	}
	
	public function ObjectManager()
	{
		return \Magento\Framework\App\ObjectManager::getInstance();
	}
	
	public function getAuthorizationToken() 
	{
		
		if ($this->_customerSession->getP21Auth()) 
		{
			return $this->_customerSession->getP21Auth();
		} else {
			// DEV Api
			 $authorizationUrl = 'http://testapi.jaybro.com.au:4443/token';
			// LIVE Api
			//$authorizationUrl = 'http://api.jaybro.com.au:88/token';
			
			$credentials = array('username' => 'apiuser', 'password' => 'test', 'grant_type' => 'password');
			$authorizationContext = array(
				'http' => array(
					'method'  => 'POST',
					'header'  => "Content-type: application/x-www-form-urlencoded\r\nConnection: close",
					'content' => http_build_query($credentials)
				)
			);
			$context = stream_context_create($authorizationContext);
			$authenticate = file_get_contents($authorizationUrl, false, $context);
			$authentication = json_decode($authenticate, true);
			$authToken = "bearer ".$authentication['access_token'];

			$this->_customerSession->setP21Auth($authToken);

			return $authToken;
		}
	}
	
	
	public function switchUOM($uomid) 
	{
		switch ($uomid) {
			case "Bale":
				$uomid = "BA";
				break;
			case "Bag":
				$uomid = "BG";
				break;
			case "Lineal Centimetre":
				$uomid = "CM";
				break;
			case "Carton":
				$uomid = "CT";
				break;
			case "Container":
				$uomid = "CTN";
				break;
			case "Daily":
				$uomid = "DAY";
				break;
			case "Dollars per day":
				$uomid = "DD";
				break;
			case "Dollars per hour":
				$uomid = "DH";
				break;
			case "Dozen":
				$uomid = "DZ";
				break;
			case "Hour":
				$uomid = "HR";
				break;
			case "Kilogram":
				$uomid = "KG";
				break;
			case "Kit":
				$uomid = "KT";
				break;
			case "Linear Metre":
				$uomid = "LM";
				break;
			case "Litre":
				$uomid = "LT";
				break;
			case "Master Carton":
				$uomid = "MCT";
				break;
			case "Millilitre":
				$uomid = "ML";
				break;
			case "Millimetre":
				$uomid = "MM";
				break;
			case "Master Pack":
				$uomid = "MPK";
				break;
			case "Monthly":
				$uomid = "MTH";
				break;
			case "Pallet":
				$uomid = "PAL";
				break;
			case "Pack":
				$uomid = "PK";
				break;
			case "Pair":
				$uomid = "PR";
				break;
			case "Quarterly":
				$uomid = "QTR";
				break;
			case "Roll":
				$uomid = "RL";
				break;
			case "Prophet 21 UOM":
				$uomid = "SKU";
				break;
			case "Supplier Pallet":
				$uomid = "SPAL";
				break;
			case "SQM":
				$uomid = "SQM";
				break;
			case "Set":
				$uomid = "ST";
				break;
			case "Weekly":
				$uomid = "WK";
				break;
			case "Yearly":
				$uomid = "YR";
				break;
			default:
				$uomid = "EA";
				break;
		}

		return $uomid;
	}

	// public function beforeSetCollection(\Magento\Catalog\Block\Product\ListProduct $subject, $result){
		// $logger = \Magento\Framework\App\ObjectManager::getInstance()->get('\Psr\Log\LoggerInterface');
		// $logger->debug(count($result));
		// return $this;
	// }
}
