<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Kadam\Erply\Setup;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Customer\Setup\CustomerSetupFactory;

/**
 * Upgrade Data script
 */

class UpgradeData implements UpgradeDataInterface
{
	
	/**
   * @var CustomerSetupFactory
   */
   private $customerSetupFactory;

	
	private $eavSetupFactory;
	

	public function __construct(
	EavSetupFactory $eavSetupFactory,
	CustomerSetupFactory $customerSetupFactory
	)
	{
		$this->customerSetupFactory = $customerSetupFactory;
		$this->eavSetupFactory = $eavSetupFactory;
	}

	public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
		
		if ($context->getVersion() && version_compare($context->getVersion(), '0.0.5') < 0) {
			$eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
			$attributeSetId = $eavSetup->getDefaultAttributeSetId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE);
			$attributeGroupId = $eavSetup->getDefaultAttributeGroupId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId);
			$groupName = $eavSetup->getAttributeGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $attributeGroupId, 'Product Details');
			$eavSetup->addAttribute(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, "erply_product_id", [
					'type'         				 => 'varchar',
					'label'                      => 'ERPLY Product Id',
					'user_defined'               => 1,
					'searchable'                 => 0,
					'visible_on_front'           => 1,
					'input'        				 => 'text',
					'is_required'				 => false,
					'visible_in_advanced_search' => 1,
					'is_unique'					 => 0,
					'sort_order'                 => 10,
					'system'       				 => 0,
					'wysiwyg_enabled'   		 => 0,
					'source' 					 => '',
					'filterable' 				 => 0,
					'comparable' 				 => 0,
				]);
			$attributeId = $eavSetup->getAttributeId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, 'erply_product_id');
			$customGroupName = 'ERPPLY Custom attributes';
			$eavSetup->addAttributeGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $customGroupName, 10);
			$eavSetup->addAttributeToGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $customGroupName, $attributeId);

		}
		
		if ($context->getVersion() && version_compare($context->getVersion(), '0.0.6') < 0) {
			$eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
			$attributeSetId = $eavSetup->getDefaultAttributeSetId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE);
			$attributeGroupId = $eavSetup->getDefaultAttributeGroupId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId);
			$groupName = $eavSetup->getAttributeGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $attributeGroupId, 'Product Details');
			$eavSetup->addAttribute(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, "erply_relatedfiles", [
					'type'         				 => 'text',
					'label'                      => 'ERPLY Files',
					'user_defined'               => 1,
					'searchable'                 => 0,
					'visible_on_front'           => 1,
					'input'        				 => 'text',
					'is_required'				 => false,
					'visible_in_advanced_search' => 1,
					'is_unique'					 => 0,
					'sort_order'                 => 11,
					'system'       				 => 0,
					'wysiwyg_enabled'   		 => 1,
					'source' 					 => '',
					'filterable' 				 => 0,
					'comparable' 				 => 0,
				]);
			$attributeId = $eavSetup->getAttributeId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, 'erply_relatedfiles');
			$customGroupName = 'ERPPLY Custom attributes';
			$eavSetup->addAttributeGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $customGroupName, 10);
			$eavSetup->addAttributeToGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $customGroupName, $attributeId);

		}
		
		
		if ($context->getVersion() && version_compare($context->getVersion(), '0.0.8') < 0) {
			
			$userAttributes = ['erply_priceListID','erply_customerID', 'erply_type_id', 'erply_groupID', 'erply_companyName', 'erply_payerID','erply_phone', 'erply_mobile','erply_fax', 'erply_birthday', 'erply_code', 'erply_integrationCode', 'erply_flagStatus', 'erply_colorStatus', 'erply_credit', 'erply_salesBlocked', 'erply_referenceNumber', 'erply_customerCardNumber', 'erply_customerType', 'erply_addressTypeID', 'erply_addressTypeName', 'erply_isPOSDefaultCustomer', 'erply_euCustomerType','erply_lastModifierUsername', 'erply_lastModifierEmployeeID', 'erply_taxExempt', 'erply_paysViaFactoring', 'erply_rewardPoints','erply_twitterID', 'erply_facebookName', 'erply_creditCardLastNumbers', 'erply_deliveryTypeID', 'erply_image', 'erply_rewardPointsDisabled', 'erply_posCouponsDisabled', 'erply_emailOptOut', 'erply_signUpStoreID', 'erply_homeStoreID','erply_countryID'];
		
			foreach ($userAttributes as $attributename) {
				$label = explode('_', $attributename);
				$customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

        	$customerSetup->addAttribute('customer', $attributename, [
            'label' => $label[1],
            'input' => 'text',
            'type' => 'varchar',
            'source' => '',
            'required' => false,
            'position' => 0,
            'visible' => true,
            'system' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => true,
            'is_filterable_in_grid' => true,
            'is_searchable_in_grid' => true,
            'backend' => ''
        ]);

        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', $attributename)
            ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_edit',
                'customer_register'
            ]]);

        $attribute->save();
		}
	}
	
	if ($context->getVersion() && version_compare($context->getVersion(), '0.0.9') < 0) {
			$eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
			$attributeSetId = $eavSetup->getDefaultAttributeSetId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE);
			$attributeGroupId = $eavSetup->getDefaultAttributeGroupId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId);
			$groupName = $eavSetup->getAttributeGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $attributeGroupId, 'Product Details');
			$eavSetup->addAttribute(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, "erply_product_group", [
					'type'         				 => 'varchar',
					'label'                      => 'ERPLY Product group',
					'user_defined'               => 1,
					'searchable'                 => 0,
					'visible_on_front'           => 1,
					'input'        				 => 'text',
					'is_required'				 => false,
					"is_used_for_promo_rules" => true,
					'visible_in_advanced_search' => 1,
					'is_unique'					 => 0,
					'sort_order'                 => 10,
					'system'       				 => 0,
					'wysiwyg_enabled'   		 => 0,
					'source' 					 => '',
					'filterable' 				 => 0,
					'comparable' 				 => 0,
				]);
			$attributeId = $eavSetup->getAttributeId(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, 'erply_product_group');
			$customGroupName = 'ERPPLY Custom attributes';
			$eavSetup->addAttributeGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $customGroupName, 10);
			$eavSetup->addAttributeToGroup(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, $attributeSetId, $customGroupName, $attributeId);

		}
		
		if ($context->getVersion() && version_compare($context->getVersion(), '0.0.10') < 0) {
			$userAttributes = ['erply_prilist'];
		
			foreach ($userAttributes as $attributename) {
				$label = explode('_', $attributename);
				$customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

        	$customerSetup->addAttribute('customer', $attributename, [
            'label' => $label[1],
            'input' => 'text',
            'type' => 'varchar',
            'source' => '',
            'required' => false,
            'position' => 0,
            'visible' => true,
            'system' => false,
            'is_used_in_grid' => false,
            'is_visible_in_grid' => false,
            'is_filterable_in_grid' => false,
            'is_searchable_in_grid' => false,
            'backend' => ''
        ]);

        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', $attributename)
            ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_edit'
            ]]);

        $attribute->save();
		}
		}
	}
	
	
    
}