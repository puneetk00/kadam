<?php
    /**
     * Webkul Hello CustomPrice Observer
     *
     * @category    Webkul
     * @package     Webkul_Hello
     * @author      Webkul Software Private Limited
     *
     */
    namespace Kadam\Erply\Observer;
 
    use Magento\Framework\Event\ObserverInterface;
    use Magento\Framework\App\RequestInterface;
 
    class CustomPrice implements ObserverInterface
    {
    	
    	public function __construct(
			\Magento\Customer\Model\Session $customerSession  	
    	){
			$this->_customerSession = $customerSession;    	
    	}
        public function execute(\Magento\Framework\Event\Observer $observer) {
				$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/t.log');
				$logger = new \Zend\Log\Logger();
				$logger->addWriter($writer);
				$logger->info('Your text message');        	
        		
        		$pr = $this->_customerSession->getPriceCached();
        		if(isset($pr) && count($pr) > 0){ 	  
    	  	  		   $item = $observer->getEvent()->getData('quote_item');           
           		 	$item = ( $item->getParentItem() ? $item->getParentItem() : $item );
           			$price = $pr[$item->getProductId()]; //set your price here
            		$item->setCustomPrice($price);
           			$item->setOriginalCustomPrice($price);
            		$item->getProduct()->setIsSuperMode(true);
            } 
        }
 
    }